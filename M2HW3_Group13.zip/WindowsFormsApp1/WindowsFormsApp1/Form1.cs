﻿/**
* 18 FEB 2018
* CSC 153
* Hillary Agbele - Responsible for program code
* Rashad Henry   - Responsible for program flowchart
* Robert Land    - Responsible for program pseudo code
* This program takes the number of tickets sold for classes of seats
* for an event and calculates the amount of revenue generated. 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      

        //This line  of code clear the user input 
        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_CASold.Text = "";
            txt_CBSold.Text = "";
            txt_CCSold.Text = "";
            txt_CARev.Text = "";
            txt_CBRev.Text = "";
            txt_CCRev.Text = "";
            txt_totalRev.Text = "";
        }
        // this line of code help the user to exit when done 
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_CalRev_Click(object sender, EventArgs e)
        {
            //declaring variable 
            double CATickets;
            double CBTickets;
            double CCTickets;
            double totalRev;
            //store the input from the user. 
            if(txt_CARev.Text != "" && txt_CBRev.Text != "" && txt_CCRev.Text != "")
            {

                //The input is then passed to the variable. 
                CATickets = double.Parse(txt_CARev.Text);
                CBTickets = double.Parse(txt_CBRev.Text);
                CCTickets = double.Parse(txt_CCRev.Text);

                CATickets = CATickets * 15.0;
                CBTickets = CBTickets * 12.0;
                CCTickets = CCTickets * 9.0;
                totalRev = CATickets + CBTickets + CCTickets;
                //when the cal. is done, the output is then passed to Revenue Generated box.
                txt_CASold.Text = CATickets.ToString("c");
                txt_CBSold.Text = CBTickets.ToString("c");
                txt_CCSold.Text = CCTickets.ToString("c");
                txt_totalRev.Text = totalRev.ToString("c");

            }
        }
    }
}
