﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_CalRev = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.ticketsSold = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textLable = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.revGenerated = new System.Windows.Forms.GroupBox();
            this.txt_CASold = new System.Windows.Forms.TextBox();
            this.txt_CCSold = new System.Windows.Forms.TextBox();
            this.txt_totalRev = new System.Windows.Forms.TextBox();
            this.txt_CBSold = new System.Windows.Forms.TextBox();
            this.txt_CARev = new System.Windows.Forms.TextBox();
            this.txt_CBRev = new System.Windows.Forms.TextBox();
            this.txt_CCRev = new System.Windows.Forms.TextBox();
            this.ticketsSold.SuspendLayout();
            this.revGenerated.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_CalRev
            // 
            this.Btn_CalRev.BackColor = System.Drawing.Color.Lime;
            this.Btn_CalRev.Location = new System.Drawing.Point(104, 342);
            this.Btn_CalRev.Name = "Btn_CalRev";
            this.Btn_CalRev.Size = new System.Drawing.Size(143, 59);
            this.Btn_CalRev.TabIndex = 0;
            this.Btn_CalRev.Text = "Calculate Revenue";
            this.Btn_CalRev.UseVisualStyleBackColor = false;
            this.Btn_CalRev.Click += new System.EventHandler(this.Btn_CalRev_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Clear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Clear.Location = new System.Drawing.Point(285, 342);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(171, 59);
            this.btn_Clear.TabIndex = 1;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.DarkRed;
            this.btn_Exit.Location = new System.Drawing.Point(474, 342);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(171, 59);
            this.btn_Exit.TabIndex = 2;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // ticketsSold
            // 
            this.ticketsSold.Controls.Add(this.txt_CCRev);
            this.ticketsSold.Controls.Add(this.txt_CBRev);
            this.ticketsSold.Controls.Add(this.txt_CARev);
            this.ticketsSold.Controls.Add(this.label3);
            this.ticketsSold.Controls.Add(this.label2);
            this.ticketsSold.Controls.Add(this.label1);
            this.ticketsSold.Controls.Add(this.textLable);
            this.ticketsSold.Location = new System.Drawing.Point(47, 22);
            this.ticketsSold.Name = "ticketsSold";
            this.ticketsSold.Size = new System.Drawing.Size(343, 304);
            this.ticketsSold.TabIndex = 3;
            this.ticketsSold.TabStop = false;
            this.ticketsSold.Text = "Tickets Sold";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Class C";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Class B:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Class A:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textLable
            // 
            this.textLable.AutoSize = true;
            this.textLable.Location = new System.Drawing.Point(16, 33);
            this.textLable.Name = "textLable";
            this.textLable.Size = new System.Drawing.Size(184, 34);
            this.textLable.TabIndex = 0;
            this.textLable.Text = "Enter the number of tickets\r\nsold for each class of seats.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Class A:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Class B:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Class C:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "Total:";
            // 
            // revGenerated
            // 
            this.revGenerated.Controls.Add(this.txt_CBSold);
            this.revGenerated.Controls.Add(this.txt_totalRev);
            this.revGenerated.Controls.Add(this.txt_CCSold);
            this.revGenerated.Controls.Add(this.txt_CASold);
            this.revGenerated.Controls.Add(this.label7);
            this.revGenerated.Controls.Add(this.label6);
            this.revGenerated.Controls.Add(this.label5);
            this.revGenerated.Controls.Add(this.label4);
            this.revGenerated.Location = new System.Drawing.Point(396, 22);
            this.revGenerated.Name = "revGenerated";
            this.revGenerated.Size = new System.Drawing.Size(325, 303);
            this.revGenerated.TabIndex = 4;
            this.revGenerated.TabStop = false;
            this.revGenerated.Text = "Revenue Generated ";
            // 
            // txt_CASold
            // 
            this.txt_CASold.Location = new System.Drawing.Point(178, 74);
            this.txt_CASold.Name = "txt_CASold";
            this.txt_CASold.ReadOnly = true;
            this.txt_CASold.Size = new System.Drawing.Size(92, 22);
            this.txt_CASold.TabIndex = 10;
            // 
            // txt_CCSold
            // 
            this.txt_CCSold.Location = new System.Drawing.Point(178, 142);
            this.txt_CCSold.Name = "txt_CCSold";
            this.txt_CCSold.ReadOnly = true;
            this.txt_CCSold.Size = new System.Drawing.Size(92, 22);
            this.txt_CCSold.TabIndex = 11;
            // 
            // txt_totalRev
            // 
            this.txt_totalRev.Location = new System.Drawing.Point(178, 175);
            this.txt_totalRev.Name = "txt_totalRev";
            this.txt_totalRev.ReadOnly = true;
            this.txt_totalRev.Size = new System.Drawing.Size(92, 22);
            this.txt_totalRev.TabIndex = 12;
            // 
            // txt_CBSold
            // 
            this.txt_CBSold.Location = new System.Drawing.Point(178, 102);
            this.txt_CBSold.Name = "txt_CBSold";
            this.txt_CBSold.ReadOnly = true;
            this.txt_CBSold.Size = new System.Drawing.Size(92, 22);
            this.txt_CBSold.TabIndex = 13;
            // 
            // txt_CARev
            // 
            this.txt_CARev.Location = new System.Drawing.Point(152, 89);
            this.txt_CARev.Name = "txt_CARev";
            this.txt_CARev.Size = new System.Drawing.Size(92, 22);
            this.txt_CARev.TabIndex = 11;
            // 
            // txt_CBRev
            // 
            this.txt_CBRev.Location = new System.Drawing.Point(152, 125);
            this.txt_CBRev.Name = "txt_CBRev";
            this.txt_CBRev.Size = new System.Drawing.Size(92, 22);
            this.txt_CBRev.TabIndex = 12;
            // 
            // txt_CCRev
            // 
            this.txt_CCRev.Location = new System.Drawing.Point(152, 165);
            this.txt_CCRev.Name = "txt_CCRev";
            this.txt_CCRev.Size = new System.Drawing.Size(92, 22);
            this.txt_CCRev.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 473);
            this.Controls.Add(this.revGenerated);
            this.Controls.Add(this.ticketsSold);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.Btn_CalRev);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.ticketsSold.ResumeLayout(false);
            this.ticketsSold.PerformLayout();
            this.revGenerated.ResumeLayout(false);
            this.revGenerated.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Btn_CalRev;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.GroupBox ticketsSold;
        private System.Windows.Forms.Label textLable;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox revGenerated;
        private System.Windows.Forms.TextBox txt_CCRev;
        private System.Windows.Forms.TextBox txt_CBRev;
        private System.Windows.Forms.TextBox txt_CARev;
        private System.Windows.Forms.TextBox txt_CBSold;
        private System.Windows.Forms.TextBox txt_totalRev;
        private System.Windows.Forms.TextBox txt_CCSold;
        private System.Windows.Forms.TextBox txt_CASold;
    }
}

