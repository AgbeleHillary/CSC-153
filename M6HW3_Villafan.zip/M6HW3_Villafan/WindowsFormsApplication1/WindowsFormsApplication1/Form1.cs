﻿/**
* 20180428
* CSC 153
* Group #5 (Michel Villafan, Hillary Agbele, Michael Freeman) 
* 
* GUI and Source code by: Michel Villafan
* FlowChart by: 
* Pseudo code by: 
* 
* Rock, Paper, Scissors game (using methods)
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Rock = 1
//Paper = 2
//Scissors = 3


namespace WindowsFormsApplication1
{
    public partial class gameForm : Form
    {
        public gameForm()
        {
            InitializeComponent();

        }

        //methoid for generating a random number
        private int getRandomNumb()
        {
            Random rand = new Random();
            int randNumb = rand.Next(1, 4);
            return randNumb;
        }
        //method for hiding all buttons
        private void HideButtons()
        {
            rockButton.Visible = false;
            paperButton.Visible = false;
            scissorsButton.Visible = false;
        }
        //method for showing all buttons
        private void ShowButtons()
        {
            rockButton.Visible = true;
            paperButton.Visible = true;
            scissorsButton.Visible = true;
        }
        //method for comparing the choices between player and computer
        private void CompareChoices(int player, int computer)
        {
            if (player == 1 && computer == 1)
            {
                //Tie! Rock == Rock
                outPutLabel.Text = "Tie! Rock == Rock";
                playAgainButton.Visible = true;
            }
            else if (player == 1 && computer == 2)
            {
                //Computer wins Paper > Rock
                outPutLabel.Text = "Computer wins Paper > Rock";
            }
            else if (player == 1 && computer == 3)
            {
                //Player wins, Rock > Scissors
                outPutLabel.Text = "Player wins, Rock > Scissors";
            }
            else if (player == 2 && computer == 1)
            {
                //Player wins, Paper > Rock
                outPutLabel.Text = "Player wins, Paper > Rock";
            }
            else if (player == 2 && computer == 2)
            {
                //Tie! Paper == Paper
                outPutLabel.Text = "Tie! Paper == Paper";
                playAgainButton.Visible = true;
            }
            else if (player == 2 && computer == 3)
            {
                //Computer wins, Paper < Scissors
                outPutLabel.Text = "Computer wins, Paper < Scissors";
            }
            if (player == 3 && computer == 1)
            {
                //Computer wins Rock > Scissors
                outPutLabel.Text = "Computer wins Rock > Scissors";
            }
            else if (player == 3 && computer == 2)
            {
                //Player wins Scissors > Paper
                outPutLabel.Text = "Player wins Scissors > Paper";
            }
            else if (player == 3 && computer == 3)
            {
                //Tie Scissors == Scissors
                outPutLabel.Text = "Tie Scissors == Scissors";
            }
            // code for testing ignore
            //testLabel_player.Text = player.ToString();
            //label_test_cpu.Text = computer.ToString();
        }
        //click event for rock, hides buttons, passes choice and cpu choice to the compare method, then displays it in a label
        private void rockButton_Click(object sender, EventArgs e)
        {
            HideButtons();
            int playerChoice = 1;
            int computerChoice = getRandomNumb();
            CompareChoices(playerChoice, computerChoice);
            outPutLabel.Visible = true;

        }
        //click event for paper, hides buttons, passes choice and cpu choice to the compare method, then displays it in a label
        private void paperButton_Click(object sender, EventArgs e)
        {
            HideButtons();
            int playerChoice = 2;
            int computerChoice = getRandomNumb();
            CompareChoices(playerChoice, computerChoice);
            outPutLabel.Visible = true;

        }
        //click event for scissors, hides buttons, passes choice and cpu choice to the compare method, then displays it in a label
        private void scissorsButton_Click(object sender, EventArgs e)
        {
            HideButtons();
            int playerChoice = 3;
            int computerChoice = getRandomNumb();
            CompareChoices(playerChoice, computerChoice);
            outPutLabel.Visible = true;

        }
        //load event, makes output label invisible
        private void gameForm_Load(object sender, EventArgs e)
        {
            
            outPutLabel.Visible = false;
        }

        //click event for play again button, just shows buttons and makes output label invisiable
        private void playAgainButton_Click(object sender, EventArgs e)
        {
            ShowButtons();
            outPutLabel.Visible = false;
        }
    }
    
}
