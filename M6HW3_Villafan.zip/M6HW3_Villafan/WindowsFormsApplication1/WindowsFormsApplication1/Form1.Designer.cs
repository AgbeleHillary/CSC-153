﻿namespace WindowsFormsApplication1
{
    partial class gameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scissorsButton = new System.Windows.Forms.Button();
            this.paperButton = new System.Windows.Forms.Button();
            this.rockButton = new System.Windows.Forms.Button();
            this.outPutLabel = new System.Windows.Forms.Label();
            this.playAgainButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // scissorsButton
            // 
            this.scissorsButton.Image = global::WindowsFormsApplication1.Properties.Resources.scissors1;
            this.scissorsButton.Location = new System.Drawing.Point(305, 12);
            this.scissorsButton.Name = "scissorsButton";
            this.scissorsButton.Size = new System.Drawing.Size(153, 186);
            this.scissorsButton.TabIndex = 2;
            this.scissorsButton.UseVisualStyleBackColor = true;
            this.scissorsButton.Click += new System.EventHandler(this.scissorsButton_Click);
            // 
            // paperButton
            // 
            this.paperButton.Image = global::WindowsFormsApplication1.Properties.Resources.paper1;
            this.paperButton.Location = new System.Drawing.Point(501, 12);
            this.paperButton.Name = "paperButton";
            this.paperButton.Size = new System.Drawing.Size(153, 186);
            this.paperButton.TabIndex = 1;
            this.paperButton.UseVisualStyleBackColor = true;
            this.paperButton.Click += new System.EventHandler(this.paperButton_Click);
            // 
            // rockButton
            // 
            this.rockButton.Image = global::WindowsFormsApplication1.Properties.Resources.rock1;
            this.rockButton.Location = new System.Drawing.Point(110, 12);
            this.rockButton.Name = "rockButton";
            this.rockButton.Size = new System.Drawing.Size(153, 186);
            this.rockButton.TabIndex = 0;
            this.rockButton.UseVisualStyleBackColor = true;
            this.rockButton.Click += new System.EventHandler(this.rockButton_Click);
            // 
            // outPutLabel
            // 
            this.outPutLabel.AutoSize = true;
            this.outPutLabel.Font = new System.Drawing.Font("Ravie", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outPutLabel.ForeColor = System.Drawing.Color.Crimson;
            this.outPutLabel.Location = new System.Drawing.Point(10, 71);
            this.outPutLabel.Name = "outPutLabel";
            this.outPutLabel.Size = new System.Drawing.Size(0, 43);
            this.outPutLabel.TabIndex = 4;
            this.outPutLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // playAgainButton
            // 
            this.playAgainButton.Location = new System.Drawing.Point(349, 215);
            this.playAgainButton.Name = "playAgainButton";
            this.playAgainButton.Size = new System.Drawing.Size(75, 23);
            this.playAgainButton.TabIndex = 5;
            this.playAgainButton.Text = "Play Again";
            this.playAgainButton.UseVisualStyleBackColor = true;
            this.playAgainButton.Click += new System.EventHandler(this.playAgainButton_Click);
            // 
            // gameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 266);
            this.Controls.Add(this.playAgainButton);
            this.Controls.Add(this.outPutLabel);
            this.Controls.Add(this.scissorsButton);
            this.Controls.Add(this.paperButton);
            this.Controls.Add(this.rockButton);
            this.Name = "gameForm";
            this.Text = "Rock, Paper, Scissors";
            this.Load += new System.EventHandler(this.gameForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rockButton;
        private System.Windows.Forms.Button paperButton;
        private System.Windows.Forms.Button scissorsButton;
        private System.Windows.Forms.Label outPutLabel;
        private System.Windows.Forms.Button playAgainButton;
    }
}

