﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 4/22/2018
* CSC 153
* Hillary Agbele
*Base on what the user select during the start up,by click on the check box this program will then cal. the amount of the service.
*/

namespace Joe_s_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //closing the program.
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            double oil = 0, lube = 0, radiator = 0, trans = 0, inspection = 0, muffler = 0, tire = 0;
            // giving the goes it value . For example oil hold's the value of 26.
            if (oilCheckBox.Checked == true)
            {
                oil = 26;
            }
            if (lubeCheckBox.Checked == true)
            {
                lube = 18;

            if (radiatorCheckBox.Checked == true)
              {
                    radiator = 30;
             }
            }
            if (tranCheckBox.Checked == true)
            {
                trans = 80;
            }
            if (inspectionCheckBox.Checked == true)
            {
                inspection = 15;
            }
            if (replaceCheckBox.Checked == true)
            {
                muffler = 100;
            }
            if (tireCheckBox.Checked == true)
            {
                tire = 20;
            }
            //collecting user input and storing it for latter use.
            double parts = double.Parse(partTextBox.Text);
                double labor = double.Parse(laborTextBox.Text);

                double oillube = OilLubeCharges(oil, lube);
                double flush = FlushCharges(radiator, trans);
                double misc = MiscCharges(inspection, muffler, tire);
                double other = otherCharges(parts, labor);
                double tax = TaxCharges(parts, labor, oillube, flush, misc, labor);
                double total = TotalCharges(oillube, flush, misc, other, tax);
                double services = oillube + flush + misc;

                serviceTextBox.Text = services.ToString();
                partsTextBox.Text = other.ToString();
                taxTextBox.Text = tax.ToString();
                totalTextBox.Text = total.ToString();
            }
        // Doing the calculation form the program 
            private double OilLubeCharges(double oil, double lube)
            {
                return oil + lube;
            }

            private double FlushCharges(double radiator, double
                    trans)
            {

                return radiator + trans;

            }

            private double MiscCharges(double inspection, double muffler, double tire)
            {
                return inspection + muffler + tire;

            }

            private double otherCharges(double parts, double labor)
            {
                return parts + labor;

            }

            private double TaxCharges(double parts, double labor, double oillube, double flush, double misc, double other)
            {
                if (parts != 0 && labor != 0 && (oillube != 0 && flush != 0 && misc != 0 && other != 0))


                {
                    return (0.06 * parts);

                }

                else

                    return 0;
            }

            private double TotalCharges(double oillube, double flush, double misc, double other, double tax)
            {
                return oillube + flush + misc + other + tax;

            }

        //Calling the codes you already created 

            private void clearButton_Click(object sender, EventArgs e)
            {
                ClearOillube();
                ClearFlushes();
                ClearMisc();
                ClearOther();
                ClearFees();

            }
        //All the code below helps clear the box when user is done and want to enter and other input 
            private void ClearOillube()
            {
                if (oilCheckBox.Checked == true)
                {
                    oilCheckBox.Checked = false;
                }
                if (lubeCheckBox.Checked == true)
                {
                    lubeCheckBox.Checked = false;
                }
            }
            private void ClearFlushes()
            {
                if (radiatorCheckBox.Checked == true)
                {
                    radiatorCheckBox.Checked = false;

                }
                if (tranCheckBox.Checked == true)
                {
                    tranCheckBox.Checked = false;
                }
            }
            private void ClearMisc()
            {
                if (inspectionCheckBox.Checked == true)
                {
                    inspectionCheckBox.Checked = false;
                }
                if (replaceCheckBox.Checked == true)
                {
                    replaceCheckBox.Checked = false;
                }
                if (tireCheckBox.Checked == true)
                {
                    tireCheckBox.Checked = false;
                }
            }
            private void ClearOther()
            {
                partTextBox.Text = null;
                laborTextBox.Text = null;

            }
            private void ClearFees()
            {
                serviceTextBox.Text = null;
                partsTextBox.Text = null;
                taxTextBox.Text = null;
                totalTextBox.Text = null;
            }
        }
    }


