﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Latin : Form
    {
        public Latin()
        {
            InitializeComponent();
        }

        private void sinisterButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Left";
        }

        private void dexterButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Right";
        }

        private void mediumButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "center";
        }
    }
}
