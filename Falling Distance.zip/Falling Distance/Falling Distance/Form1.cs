﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 4/20/2018
* CSC 153
* Hillary Agbele
* Base on the time enter this program will cal. m/ sec of a falling object.
*/

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_cal_Click(object sender, EventArgs e)
        {
            double time, value;
            time = double.Parse(timetextBox.Text);
            value = FallingDistance(time);// cal the method created 
            MessageBox.Show("Distance of the objeact is: " + value + " meter per second");// displaying the message.

        }

        //creating a method to do the cal.
        private double FallingDistance(double time)
        {
            return 0.5 * 9.8 * (time * time);
        }
    }
}
