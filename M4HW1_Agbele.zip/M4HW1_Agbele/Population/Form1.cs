﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 3/25/2018
* CSC 153
* Hillary AGbele
* this program help's cal. growth over time base on the user input 
*/

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            //declearing my veriable 
            int noOfOrganism = 0;
            int avglncrease = 0;
            int noDays = 0;
            int count = 1;
            double approximatePouplation = 0.0;

            PopuIationlist.Items.Clear();

            if (!string.IsNullOrEmpty(NumbOrganism.Text) && !string.IsNullOrEmpty(txtArvgIncrease.Text)
            && !string.IsNullOrEmpty(txtNumbOfDay.Text))
            {
            //pasing the user input to the veriable 
                noOfOrganism = Convert.ToInt32(NumbOrganism.Text);
                avglncrease = Convert.ToInt32(txtArvgIncrease.Text);
                noDays = Convert.ToInt32(txtNumbOfDay.Text);
                approximatePouplation = noOfOrganism;

                while (count <= noDays)

                    //program cal.poplation over time
                {
                    PopuIationlist.Items.Add("Day " + count.ToString() + " - Approximate Population is " + approximatePouplation.ToString("0.0"));

                    approximatePouplation = approximatePouplation + (approximatePouplation * avglncrease / 100);

                    count++;

                }   // while loop ends here 

            }//if statement ends here

        }// Click end here 


    }
}
        
