﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/7/18
* CSC 153
* Hillary Agbele
* This program calculates MPG from the user input 
*/

namespace WindowsFormsApplication1
{
    public partial class discription1 : Form
    {
        public discription1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            double miles;
            double gallons;
            double mpg;

            if (double.TryParse(milesTextBox.Text, out miles))
            {

                if (double.TryParse(gallonsTextBox.Text, out gallons))
                { 
                    mpg = miles / gallons;

                    mpgLabel.Text = mpg.ToString("n1");
                }
                else
                {

                    MessageBox.Show("Invalid input for gallons.");
                }
            }
            else
            {
                MessageBox.Show("Invalid input for miles.");
            }
        }
    

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}