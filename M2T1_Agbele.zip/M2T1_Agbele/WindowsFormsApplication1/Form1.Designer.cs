﻿namespace WindowsFormsApplication1
{
    partial class discription1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mileTextBox = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.milesTextBox = new System.Windows.Forms.MaskedTextBox();
            this.gallonsTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.mpgLabel = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // mileTextBox
            // 
            this.mileTextBox.AutoSize = true;
            this.mileTextBox.Location = new System.Drawing.Point(12, 28);
            this.mileTextBox.Name = "mileTextBox";
            this.mileTextBox.Size = new System.Drawing.Size(166, 13);
            this.mileTextBox.TabIndex = 0;
            this.mileTextBox.Text = "Enter the number of miles Driven: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter the gallons of gas used:";
            // 
            // CalculateButton
            // 
            this.CalculateButton.Location = new System.Drawing.Point(51, 213);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(76, 34);
            this.CalculateButton.TabIndex = 2;
            this.CalculateButton.Text = "Calculate MPG";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(147, 212);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(73, 34);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // milesTextBox
            // 
            this.milesTextBox.Location = new System.Drawing.Point(181, 25);
            this.milesTextBox.Name = "milesTextBox";
            this.milesTextBox.Size = new System.Drawing.Size(88, 20);
            this.milesTextBox.TabIndex = 4;
            // 
            // gallonsTextBox
            // 
            this.gallonsTextBox.Location = new System.Drawing.Point(181, 52);
            this.gallonsTextBox.Name = "gallonsTextBox";
            this.gallonsTextBox.Size = new System.Drawing.Size(88, 20);
            this.gallonsTextBox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Your car\'s MPG is :";
            // 
            // mpgLabel
            // 
            this.mpgLabel.Location = new System.Drawing.Point(181, 91);
            this.mpgLabel.Name = "mpgLabel";
            this.mpgLabel.Size = new System.Drawing.Size(74, 20);
            this.mpgLabel.TabIndex = 7;
            // 
            // discription1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.mpgLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gallonsTextBox);
            this.Controls.Add(this.milesTextBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mileTextBox);
            this.Name = "discription1";
            this.Text = "Fuel Economy ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label mileTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.MaskedTextBox milesTextBox;
        private System.Windows.Forms.MaskedTextBox gallonsTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox mpgLabel;
    }
}

