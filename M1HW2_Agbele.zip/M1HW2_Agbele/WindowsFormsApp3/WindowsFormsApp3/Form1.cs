﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 1/31/2018
* CSC 153
* Hillary Agbele
* This program display a messages after clicking ont the cards
*/

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sixofHeart_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Six of heart***";
        }

        private void nineofSpade_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Nine of Spade*** ";
        }

        private void jackofDiamond_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Jack of Diamond***";

        }

        private void kingofDiamond_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***King of Diamond***";
        }

        private void JokerCard_Click(object sender, EventArgs e)
        {
            cardLable.Text = "Why didn't Alexa  go to the store. \n becasue the Line was too long ";
      
        }

    }
}
