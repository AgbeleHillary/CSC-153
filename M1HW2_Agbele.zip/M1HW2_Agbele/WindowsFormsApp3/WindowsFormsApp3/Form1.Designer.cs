﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kingofDiamond = new System.Windows.Forms.PictureBox();
            this.jackofDiamond = new System.Windows.Forms.PictureBox();
            this.sixofHeart = new System.Windows.Forms.PictureBox();
            this.nineofSpade = new System.Windows.Forms.PictureBox();
            this.JokerCard = new System.Windows.Forms.PictureBox();
            this.displayLable = new System.Windows.Forms.Label();
            this.cardLable = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.kingofDiamond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jackofDiamond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixofHeart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineofSpade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.JokerCard)).BeginInit();
            this.SuspendLayout();
            // 
            // kingofDiamond
            // 
            this.kingofDiamond.Image = global::WindowsFormsApp3.Properties.Resources.king;
            this.kingofDiamond.Location = new System.Drawing.Point(982, 54);
            this.kingofDiamond.Name = "kingofDiamond";
            this.kingofDiamond.Size = new System.Drawing.Size(227, 287);
            this.kingofDiamond.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kingofDiamond.TabIndex = 4;
            this.kingofDiamond.TabStop = false;
            this.kingofDiamond.Click += new System.EventHandler(this.kingofDiamond_Click);
            // 
            // jackofDiamond
            // 
            this.jackofDiamond.Image = global::WindowsFormsApp3.Properties.Resources.joker1;
            this.jackofDiamond.Location = new System.Drawing.Point(740, 54);
            this.jackofDiamond.Name = "jackofDiamond";
            this.jackofDiamond.Size = new System.Drawing.Size(227, 287);
            this.jackofDiamond.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.jackofDiamond.TabIndex = 3;
            this.jackofDiamond.TabStop = false;
            this.jackofDiamond.Click += new System.EventHandler(this.jackofDiamond_Click);
            // 
            // sixofHeart
            // 
            this.sixofHeart.Image = global::WindowsFormsApp3.Properties.Resources.six_2;
            this.sixofHeart.Location = new System.Drawing.Point(12, 54);
            this.sixofHeart.Name = "sixofHeart";
            this.sixofHeart.Size = new System.Drawing.Size(227, 287);
            this.sixofHeart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sixofHeart.TabIndex = 2;
            this.sixofHeart.TabStop = false;
            this.sixofHeart.Click += new System.EventHandler(this.sixofHeart_Click);
            // 
            // nineofSpade
            // 
            this.nineofSpade.Image = global::WindowsFormsApp3.Properties.Resources._9;
            this.nineofSpade.Location = new System.Drawing.Point(255, 54);
            this.nineofSpade.Name = "nineofSpade";
            this.nineofSpade.Size = new System.Drawing.Size(227, 287);
            this.nineofSpade.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nineofSpade.TabIndex = 1;
            this.nineofSpade.TabStop = false;
            this.nineofSpade.Click += new System.EventHandler(this.nineofSpade_Click);
            // 
            // JokerCard
            // 
            this.JokerCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.JokerCard.Image = global::WindowsFormsApp3.Properties.Resources.joker;
            this.JokerCard.Location = new System.Drawing.Point(488, 65);
            this.JokerCard.Name = "JokerCard";
            this.JokerCard.Size = new System.Drawing.Size(237, 267);
            this.JokerCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.JokerCard.TabIndex = 0;
            this.JokerCard.TabStop = false;
            this.JokerCard.Click += new System.EventHandler(this.JokerCard_Click);
            // 
            // displayLable
            // 
            this.displayLable.AutoSize = true;
            this.displayLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLable.Location = new System.Drawing.Point(259, 9);
            this.displayLable.Name = "displayLable";
            this.displayLable.Size = new System.Drawing.Size(629, 32);
            this.displayLable.TabIndex = 5;
            this.displayLable.Text = "***Click on the cards to display their name.***";
            // 
            // cardLable
            // 
            this.cardLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardLable.Location = new System.Drawing.Point(12, 361);
            this.cardLable.Name = "cardLable";
            this.cardLable.Size = new System.Drawing.Size(1197, 38);
            this.cardLable.TabIndex = 6;
            this.cardLable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 482);
            this.Controls.Add(this.cardLable);
            this.Controls.Add(this.displayLable);
            this.Controls.Add(this.kingofDiamond);
            this.Controls.Add(this.jackofDiamond);
            this.Controls.Add(this.sixofHeart);
            this.Controls.Add(this.nineofSpade);
            this.Controls.Add(this.JokerCard);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.kingofDiamond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jackofDiamond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixofHeart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineofSpade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.JokerCard)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox JokerCard;
        private System.Windows.Forms.PictureBox nineofSpade;
        private System.Windows.Forms.PictureBox sixofHeart;
        private System.Windows.Forms.PictureBox jackofDiamond;
        private System.Windows.Forms.PictureBox kingofDiamond;
        private System.Windows.Forms.Label displayLable;
        private System.Windows.Forms.MaskedTextBox cardLable;
    }
}

