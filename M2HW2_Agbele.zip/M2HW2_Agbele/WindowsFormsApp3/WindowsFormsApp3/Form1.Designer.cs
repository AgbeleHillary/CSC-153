﻿namespace WindowsFormsApp3
{
    partial class Sentence_maker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IbI_resuIt = new System.Windows.Forms.TextBox();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_small = new System.Windows.Forms.Button();
            this.btn_beautiful = new System.Windows.Forms.Button();
            this.btn_space = new System.Windows.Forms.Button();
            this.btn_spoke = new System.Windows.Forms.Button();
            this.btn_point = new System.Windows.Forms.Button();
            this.btn_rode = new System.Windows.Forms.Button();
            this.btn_period = new System.Windows.Forms.Button();
            this.btn_laughed_at = new System.Windows.Forms.Button();
            this.btn_big = new System.Windows.Forms.Button();
            this.btn_looked_at = new System.Windows.Forms.Button();
            this.btn_strange = new System.Windows.Forms.Button();
            this.btn_drive = new System.Windows.Forms.Button();
            this.btn_bicycle = new System.Windows.Forms.Button();
            this.btn_man = new System.Windows.Forms.Button();
            this.btn_woman = new System.Windows.Forms.Button();
            this.btn_dog = new System.Windows.Forms.Button();
            this.btn_cat = new System.Windows.Forms.Button();
            this.btn_car = new System.Windows.Forms.Button();
            this.btnthe = new System.Windows.Forms.Button();
            this.btn_The = new System.Windows.Forms.Button();
            this.btnan = new System.Windows.Forms.Button();
            this.btn_An = new System.Windows.Forms.Button();
            this.btna = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // IbI_resuIt
            // 
            this.IbI_resuIt.Location = new System.Drawing.Point(3, 34);
            this.IbI_resuIt.Name = "IbI_resuIt";
            this.IbI_resuIt.Size = new System.Drawing.Size(578, 22);
            this.IbI_resuIt.TabIndex = 0;
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(167, 275);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(110, 45);
            this.btn_clear.TabIndex = 1;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(335, 275);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(136, 45);
            this.btn_exit.TabIndex = 2;
            this.btn_exit.Text = "Exit ";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(107, 80);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(58, 26);
            this.btn_A.TabIndex = 3;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_small
            // 
            this.btn_small.Location = new System.Drawing.Point(359, 126);
            this.btn_small.Name = "btn_small";
            this.btn_small.Size = new System.Drawing.Size(58, 26);
            this.btn_small.TabIndex = 4;
            this.btn_small.Text = " small ";
            this.btn_small.UseVisualStyleBackColor = true;
            this.btn_small.Click += new System.EventHandler(this.btn_small_Click);
            // 
            // btn_beautiful
            // 
            this.btn_beautiful.Location = new System.Drawing.Point(280, 171);
            this.btn_beautiful.Name = "btn_beautiful";
            this.btn_beautiful.Size = new System.Drawing.Size(95, 26);
            this.btn_beautiful.TabIndex = 5;
            this.btn_beautiful.Text = "beautiful";
            this.btn_beautiful.UseVisualStyleBackColor = true;
            this.btn_beautiful.Click += new System.EventHandler(this.btn_beautiful_Click);
            // 
            // btn_space
            // 
            this.btn_space.AccessibleName = "";
            this.btn_space.Location = new System.Drawing.Point(167, 213);
            this.btn_space.Name = "btn_space";
            this.btn_space.Size = new System.Drawing.Size(73, 31);
            this.btn_space.TabIndex = 6;
            this.btn_space.Text = " ";
            this.btn_space.UseVisualStyleBackColor = true;
            this.btn_space.Click += new System.EventHandler(this.btn_space_Click);
            // 
            // btn_spoke
            // 
            this.btn_spoke.Location = new System.Drawing.Point(122, 171);
            this.btn_spoke.Name = "btn_spoke";
            this.btn_spoke.Size = new System.Drawing.Size(58, 26);
            this.btn_spoke.TabIndex = 7;
            this.btn_spoke.Text = "spoke to ";
            this.btn_spoke.UseVisualStyleBackColor = true;
            this.btn_spoke.Click += new System.EventHandler(this.btn_spoke_Click);
            // 
            // btn_point
            // 
            this.btn_point.Location = new System.Drawing.Point(346, 213);
            this.btn_point.Name = "btn_point";
            this.btn_point.Size = new System.Drawing.Size(58, 26);
            this.btn_point.TabIndex = 8;
            this.btn_point.Text = "!";
            this.btn_point.UseVisualStyleBackColor = true;
            this.btn_point.Click += new System.EventHandler(this.btn_point_Click);
            // 
            // btn_rode
            // 
            this.btn_rode.Location = new System.Drawing.Point(154, 126);
            this.btn_rode.Name = "btn_rode";
            this.btn_rode.Size = new System.Drawing.Size(58, 26);
            this.btn_rode.TabIndex = 9;
            this.btn_rode.Text = "rode";
            this.btn_rode.UseVisualStyleBackColor = true;
            // 
            // btn_period
            // 
            this.btn_period.Location = new System.Drawing.Point(257, 213);
            this.btn_period.Name = "btn_period";
            this.btn_period.Size = new System.Drawing.Size(58, 26);
            this.btn_period.TabIndex = 10;
            this.btn_period.Text = ".";
            this.btn_period.UseVisualStyleBackColor = true;
            this.btn_period.Click += new System.EventHandler(this.btn_period_Click);
            // 
            // btn_laughed_at
            // 
            this.btn_laughed_at.Location = new System.Drawing.Point(64, 126);
            this.btn_laughed_at.Name = "btn_laughed_at";
            this.btn_laughed_at.Size = new System.Drawing.Size(88, 26);
            this.btn_laughed_at.TabIndex = 11;
            this.btn_laughed_at.Text = "laughed at";
            this.btn_laughed_at.UseVisualStyleBackColor = true;
            this.btn_laughed_at.Click += new System.EventHandler(this.btn_laughed_at_Click);
            // 
            // btn_big
            // 
            this.btn_big.Location = new System.Drawing.Point(295, 126);
            this.btn_big.Name = "btn_big";
            this.btn_big.Size = new System.Drawing.Size(58, 26);
            this.btn_big.TabIndex = 12;
            this.btn_big.Text = "big";
            this.btn_big.UseVisualStyleBackColor = true;
            this.btn_big.Click += new System.EventHandler(this.btn_big_Click);
            // 
            // btn_looked_at
            // 
            this.btn_looked_at.Location = new System.Drawing.Point(186, 171);
            this.btn_looked_at.Name = "btn_looked_at";
            this.btn_looked_at.Size = new System.Drawing.Size(88, 26);
            this.btn_looked_at.TabIndex = 13;
            this.btn_looked_at.Text = "looked at ";
            this.btn_looked_at.UseVisualStyleBackColor = true;
            this.btn_looked_at.Click += new System.EventHandler(this.btn_looked_at_Click);
            // 
            // btn_strange
            // 
            this.btn_strange.Location = new System.Drawing.Point(47, 171);
            this.btn_strange.Name = "btn_strange";
            this.btn_strange.Size = new System.Drawing.Size(69, 26);
            this.btn_strange.TabIndex = 14;
            this.btn_strange.Text = "strange";
            this.btn_strange.UseVisualStyleBackColor = true;
            this.btn_strange.Click += new System.EventHandler(this.btn_strange_Click);
            // 
            // btn_drive
            // 
            this.btn_drive.Location = new System.Drawing.Point(43, 80);
            this.btn_drive.Name = "btn_drive";
            this.btn_drive.Size = new System.Drawing.Size(58, 26);
            this.btn_drive.TabIndex = 15;
            this.btn_drive.Text = "drive";
            this.btn_drive.UseVisualStyleBackColor = true;
            this.btn_drive.Click += new System.EventHandler(this.btn_drive_Click);
            // 
            // btn_bicycle
            // 
            this.btn_bicycle.Location = new System.Drawing.Point(472, 171);
            this.btn_bicycle.Name = "btn_bicycle";
            this.btn_bicycle.Size = new System.Drawing.Size(73, 26);
            this.btn_bicycle.TabIndex = 16;
            this.btn_bicycle.Text = "bicycle";
            this.btn_bicycle.UseVisualStyleBackColor = true;
            this.btn_bicycle.Click += new System.EventHandler(this.btn_bicycle_Click);
            // 
            // btn_man
            // 
            this.btn_man.Location = new System.Drawing.Point(218, 126);
            this.btn_man.Name = "btn_man";
            this.btn_man.Size = new System.Drawing.Size(58, 26);
            this.btn_man.TabIndex = 17;
            this.btn_man.Text = "man";
            this.btn_man.UseVisualStyleBackColor = true;
            this.btn_man.Click += new System.EventHandler(this.btn_man_Click);
            // 
            // btn_woman
            // 
            this.btn_woman.Location = new System.Drawing.Point(381, 171);
            this.btn_woman.Name = "btn_woman";
            this.btn_woman.Size = new System.Drawing.Size(85, 26);
            this.btn_woman.TabIndex = 18;
            this.btn_woman.Text = "woman";
            this.btn_woman.UseVisualStyleBackColor = true;
            this.btn_woman.Click += new System.EventHandler(this.btn_woman_Click);
            // 
            // btn_dog
            // 
            this.btn_dog.Location = new System.Drawing.Point(423, 126);
            this.btn_dog.Name = "btn_dog";
            this.btn_dog.Size = new System.Drawing.Size(58, 26);
            this.btn_dog.TabIndex = 19;
            this.btn_dog.Text = "dog";
            this.btn_dog.UseVisualStyleBackColor = true;
            this.btn_dog.Click += new System.EventHandler(this.btn_dog_Click);
            // 
            // btn_cat
            // 
            this.btn_cat.Location = new System.Drawing.Point(487, 80);
            this.btn_cat.Name = "btn_cat";
            this.btn_cat.Size = new System.Drawing.Size(58, 26);
            this.btn_cat.TabIndex = 20;
            this.btn_cat.Text = "cat";
            this.btn_cat.UseVisualStyleBackColor = true;
            this.btn_cat.Click += new System.EventHandler(this.btn_cat_Click);
            // 
            // btn_car
            // 
            this.btn_car.Location = new System.Drawing.Point(487, 126);
            this.btn_car.Name = "btn_car";
            this.btn_car.Size = new System.Drawing.Size(58, 26);
            this.btn_car.TabIndex = 21;
            this.btn_car.Text = "car";
            this.btn_car.UseVisualStyleBackColor = true;
            this.btn_car.Click += new System.EventHandler(this.btn_car_Click);
            // 
            // btnthe
            // 
            this.btnthe.Location = new System.Drawing.Point(423, 80);
            this.btnthe.Name = "btnthe";
            this.btnthe.Size = new System.Drawing.Size(58, 26);
            this.btnthe.TabIndex = 22;
            this.btnthe.Text = "the";
            this.btnthe.UseVisualStyleBackColor = true;
            this.btnthe.Click += new System.EventHandler(this.btnthe_Click);
            // 
            // btn_The
            // 
            this.btn_The.Location = new System.Drawing.Point(359, 80);
            this.btn_The.Name = "btn_The";
            this.btn_The.Size = new System.Drawing.Size(58, 26);
            this.btn_The.TabIndex = 23;
            this.btn_The.Text = "The";
            this.btn_The.UseVisualStyleBackColor = true;
            this.btn_The.Click += new System.EventHandler(this.btn_The_Click);
            // 
            // btnan
            // 
            this.btnan.Location = new System.Drawing.Point(295, 80);
            this.btnan.Name = "btnan";
            this.btnan.Size = new System.Drawing.Size(58, 26);
            this.btnan.TabIndex = 24;
            this.btnan.Text = "an";
            this.btnan.UseVisualStyleBackColor = true;
            this.btnan.Click += new System.EventHandler(this.btnan_Click);
            // 
            // btn_An
            // 
            this.btn_An.Location = new System.Drawing.Point(231, 80);
            this.btn_An.Name = "btn_An";
            this.btn_An.Size = new System.Drawing.Size(58, 26);
            this.btn_An.TabIndex = 25;
            this.btn_An.Text = "An";
            this.btn_An.UseVisualStyleBackColor = true;
            this.btn_An.Click += new System.EventHandler(this.btn_An_Click);
            // 
            // btna
            // 
            this.btna.Location = new System.Drawing.Point(171, 80);
            this.btna.Name = "btna";
            this.btna.Size = new System.Drawing.Size(58, 26);
            this.btna.TabIndex = 26;
            this.btna.Text = "a";
            this.btna.UseVisualStyleBackColor = true;
            this.btna.Click += new System.EventHandler(this.btna_Click);
            // 
            // Sentence_maker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 342);
            this.Controls.Add(this.btna);
            this.Controls.Add(this.btn_An);
            this.Controls.Add(this.btnan);
            this.Controls.Add(this.btn_The);
            this.Controls.Add(this.btnthe);
            this.Controls.Add(this.btn_car);
            this.Controls.Add(this.btn_cat);
            this.Controls.Add(this.btn_dog);
            this.Controls.Add(this.btn_woman);
            this.Controls.Add(this.btn_man);
            this.Controls.Add(this.btn_bicycle);
            this.Controls.Add(this.btn_drive);
            this.Controls.Add(this.btn_strange);
            this.Controls.Add(this.btn_looked_at);
            this.Controls.Add(this.btn_big);
            this.Controls.Add(this.btn_laughed_at);
            this.Controls.Add(this.btn_period);
            this.Controls.Add(this.btn_rode);
            this.Controls.Add(this.btn_point);
            this.Controls.Add(this.btn_spoke);
            this.Controls.Add(this.btn_space);
            this.Controls.Add(this.btn_beautiful);
            this.Controls.Add(this.btn_small);
            this.Controls.Add(this.btn_A);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.IbI_resuIt);
            this.Name = "Sentence_maker";
            this.Text = "Sentence Maker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IbI_resuIt;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_small;
        private System.Windows.Forms.Button btn_beautiful;
        private System.Windows.Forms.Button btn_space;
        private System.Windows.Forms.Button btn_spoke;
        private System.Windows.Forms.Button btn_point;
        private System.Windows.Forms.Button btn_rode;
        private System.Windows.Forms.Button btn_period;
        private System.Windows.Forms.Button btn_laughed_at;
        private System.Windows.Forms.Button btn_big;
        private System.Windows.Forms.Button btn_looked_at;
        private System.Windows.Forms.Button btn_strange;
        private System.Windows.Forms.Button btn_drive;
        private System.Windows.Forms.Button btn_bicycle;
        private System.Windows.Forms.Button btn_man;
        private System.Windows.Forms.Button btn_woman;
        private System.Windows.Forms.Button btn_dog;
        private System.Windows.Forms.Button btn_cat;
        private System.Windows.Forms.Button btn_car;
        private System.Windows.Forms.Button btnthe;
        private System.Windows.Forms.Button btn_The;
        private System.Windows.Forms.Button btnan;
        private System.Windows.Forms.Button btn_An;
        private System.Windows.Forms.Button btna;
    }
}

