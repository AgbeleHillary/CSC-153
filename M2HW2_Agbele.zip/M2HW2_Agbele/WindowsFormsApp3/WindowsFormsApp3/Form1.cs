﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/13/2018 
* CSC 153
* Hillary Agbele
* The program make sentence based on the button you click
*/



namespace WindowsFormsApp3
{
    public partial class Sentence_maker : Form
    {
        public Sentence_maker()
        {
            InitializeComponent();
        }
        // this help create the sentence by click on the button 
        private void btn_A_Click(object sender, EventArgs e)
        {

            IbI_resuIt.Text = btn_A.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_big.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_cat.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_looked_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_small.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_dog.Text + btn_period.Text;
        }

        private void btna_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_man.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_rode.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_bicycle.Text + btn_period.Text.Replace("(space)", " ");
        }

        private void btn_An_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_An.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_woman.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_looked_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_period.Text;
        }

        private void btn_The_Click(object sender, EventArgs e)
        {
          
            IbI_resuIt.Text = btn_The.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_spoke.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_beautiful.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_woman.Text + btn_space.Text;
        }

        private void btnthe_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_A.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_looked_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btnthe.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_beautiful.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_dog.Text + btn_period.Text;
        }

        private void btnan_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_dog.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_spoke.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btnan.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_woman.Text + btn_period.Text;
        }

        private void btn_man_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_man.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_laughed_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_beautiful.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_woman.Text + btn_period.Text;
        }

        private void btn_woman_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_woman.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_rode.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_car.Text + btn_period.Text;
        }

        private void btn_dog_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_dog.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_laughed_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_cat.Text + btn_period.Text;

        }

        private void btn_cat_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_cat.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_looked_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_period.Text;
        }

        private void btn_car_Click(object sender, EventArgs e)
        {

            IbI_resuIt.Text = btn_man.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_rode.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_beautiful.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_car.Text + btn_period;
        }

        private void btn_bicycle_Click(object sender, EventArgs e)
        {

            IbI_resuIt.Text = btn_woman.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_rode.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_bicycle.Text + btn_period.Text;
        }

        private void btn_beautiful_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_beautiful.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_woman.Text  + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_spoke.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_period.Text;
        }

        private void btn_big_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_big.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_cat.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_laughed_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_small.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_dog.Text + btn_period.Text;
        }

        private void btn_small_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_small.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_woman.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_looked_at.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_big.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_period.Text;
        }

        private void btn_strange_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_strange.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_space.Text.Replace("( space)", " ");
            IbI_resuIt.Text += btn_rode.Text + btn_space.Text.Replace("( space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("( space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_car.Text + btn_period.Text;
        }

        private void btn_looked_at_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_The.Text + btn_space.Text.Replace("(space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_looked_at.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_bicycle.Text + btn_period.Text;
        }

        private void btn_spoke_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btna.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_big.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_cat.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_spoke.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_small.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_cat.Text + btn_period.Text;
                    }

        private void btn_laughed_at_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_strange.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_laughed_at.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_small.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_period.Text;
        }

        private void btn_drive_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_woman.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_drive.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_car.Text + btn_period.Text;
        }

        private void btn_space_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_strange.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_laughed_at.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_small.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_dog.Text + btn_period.Text;
        }

        private void btn_period_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = btn_beautiful.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_woman.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_spoke.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_strange.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_man.Text + btn_period.Text;
        }

        private void btn_point_Click(object sender, EventArgs e)
        {

            IbI_resuIt.Text = btn_dog.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_drive.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btna.Text + btn_space.Text.Replace("( Space)", " ");
            IbI_resuIt.Text += btn_car.Text + btn_point.Text; 
        }
        //the method exit the user from the program 
        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
         //this clear the display lable 
        private void btn_clear_Click(object sender, EventArgs e)
        {
            IbI_resuIt.Text = "";
        }
    }
}
