﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name1 = new System.Windows.Forms.Label();
            this.name2 = new System.Windows.Forms.Label();
            this.name3 = new System.Windows.Forms.Label();
            this.name4 = new System.Windows.Forms.Label();
            this.btn_format = new System.Windows.Forms.Button();
            this.textFirstName = new System.Windows.Forms.TextBox();
            this.textMiddleName = new System.Windows.Forms.TextBox();
            this.textLastName = new System.Windows.Forms.TextBox();
            this.textTitle = new System.Windows.Forms.TextBox();
            this.Out_Put = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // name1
            // 
            this.name1.AutoSize = true;
            this.name1.Location = new System.Drawing.Point(30, 35);
            this.name1.Name = "name1";
            this.name1.Size = new System.Drawing.Size(76, 17);
            this.name1.TabIndex = 0;
            this.name1.Text = "first Name ";
            // 
            // name2
            // 
            this.name2.AutoSize = true;
            this.name2.Location = new System.Drawing.Point(30, 71);
            this.name2.Name = "name2";
            this.name2.Size = new System.Drawing.Size(85, 17);
            this.name2.TabIndex = 1;
            this.name2.Text = "Middle initial";
            // 
            // name3
            // 
            this.name3.AutoSize = true;
            this.name3.Location = new System.Drawing.Point(30, 111);
            this.name3.Name = "name3";
            this.name3.Size = new System.Drawing.Size(80, 17);
            this.name3.TabIndex = 2;
            this.name3.Text = "Last Name ";
            // 
            // name4
            // 
            this.name4.AutoSize = true;
            this.name4.Location = new System.Drawing.Point(30, 149);
            this.name4.Name = "name4";
            this.name4.Size = new System.Drawing.Size(35, 17);
            this.name4.TabIndex = 3;
            this.name4.Text = "Title";
            // 
            // btn_format
            // 
            this.btn_format.Location = new System.Drawing.Point(113, 201);
            this.btn_format.Name = "btn_format";
            this.btn_format.Size = new System.Drawing.Size(184, 55);
            this.btn_format.TabIndex = 4;
            this.btn_format.Text = "Format Name ";
            this.btn_format.UseVisualStyleBackColor = true;
            this.btn_format.Click += new System.EventHandler(this.btn_format_Click);
            // 
            // textFirstName
            // 
            this.textFirstName.Location = new System.Drawing.Point(131, 35);
            this.textFirstName.Name = "textFirstName";
            this.textFirstName.Size = new System.Drawing.Size(166, 22);
            this.textFirstName.TabIndex = 5;
            // 
            // textMiddleName
            // 
            this.textMiddleName.Location = new System.Drawing.Point(131, 71);
            this.textMiddleName.Name = "textMiddleName";
            this.textMiddleName.Size = new System.Drawing.Size(166, 22);
            this.textMiddleName.TabIndex = 6;
            // 
            // textLastName
            // 
            this.textLastName.Location = new System.Drawing.Point(131, 111);
            this.textLastName.Name = "textLastName";
            this.textLastName.Size = new System.Drawing.Size(166, 22);
            this.textLastName.TabIndex = 7;
            // 
            // textTitle
            // 
            this.textTitle.Location = new System.Drawing.Point(131, 146);
            this.textTitle.Name = "textTitle";
            this.textTitle.Size = new System.Drawing.Size(166, 22);
            this.textTitle.TabIndex = 8;
            // 
            // Out_Put
            // 
            this.Out_Put.FormattingEnabled = true;
            this.Out_Put.ItemHeight = 16;
            this.Out_Put.Location = new System.Drawing.Point(319, 12);
            this.Out_Put.Name = "Out_Put";
            this.Out_Put.Size = new System.Drawing.Size(279, 244);
            this.Out_Put.TabIndex = 10;
            //this.Out_Put.SelectedIndexChanged += new System.EventHandler(this.Out_Put_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 276);
            this.Controls.Add(this.Out_Put);
            this.Controls.Add(this.textTitle);
            this.Controls.Add(this.textLastName);
            this.Controls.Add(this.textMiddleName);
            this.Controls.Add(this.textFirstName);
            this.Controls.Add(this.btn_format);
            this.Controls.Add(this.name4);
            this.Controls.Add(this.name3);
            this.Controls.Add(this.name2);
            this.Controls.Add(this.name1);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name1;
        private System.Windows.Forms.Label name2;
        private System.Windows.Forms.Label name3;
        private System.Windows.Forms.Label name4;
        private System.Windows.Forms.Button btn_format;
        private System.Windows.Forms.TextBox textFirstName;
        private System.Windows.Forms.TextBox textMiddleName;
        private System.Windows.Forms.TextBox textLastName;
        private System.Windows.Forms.TextBox textTitle;
        private System.Windows.Forms.ListBox Out_Put;
    }
}

