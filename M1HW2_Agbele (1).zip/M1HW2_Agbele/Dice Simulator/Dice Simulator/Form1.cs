﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 3/25/2018
* CSC 153
* Hillary AGbele
* this program display random dice each time user click roll
*/

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Roll_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            //program getting image from image list
            int index1 = rand.Next(DiceList.Images.Count);
            int index2 = rand.Next(DiceList.Images.Count);
           
            
            //program displaying image
            picBox1.Image = DiceList.Images[index1];
            picBox2.Image = DiceList.Images[index2];
        }
    }
}
