﻿namespace Dice_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_Roll = new System.Windows.Forms.Button();
            this.DiceList = new System.Windows.Forms.ImageList(this.components);
            this.picBox1 = new System.Windows.Forms.PictureBox();
            this.picBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Roll
            // 
            this.btn_Roll.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Roll.Location = new System.Drawing.Point(92, 235);
            this.btn_Roll.Name = "btn_Roll";
            this.btn_Roll.Size = new System.Drawing.Size(227, 53);
            this.btn_Roll.TabIndex = 0;
            this.btn_Roll.Text = "ROLL";
            this.btn_Roll.UseVisualStyleBackColor = true;
            this.btn_Roll.Click += new System.EventHandler(this.btn_Roll_Click);
            // 
            // DiceList
            // 
            this.DiceList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("DiceList.ImageStream")));
            this.DiceList.TransparentColor = System.Drawing.Color.Transparent;
            this.DiceList.Images.SetKeyName(0, "Die1.BMP");
            this.DiceList.Images.SetKeyName(1, "Die2.BMP");
            this.DiceList.Images.SetKeyName(2, "Die3.BMP");
            this.DiceList.Images.SetKeyName(3, "Die4.BMP");
            this.DiceList.Images.SetKeyName(4, "Die5.BMP");
            this.DiceList.Images.SetKeyName(5, "Die6.BMP");
            // 
            // picBox1
            // 
            this.picBox1.Location = new System.Drawing.Point(35, 43);
            this.picBox1.Name = "picBox1";
            this.picBox1.Size = new System.Drawing.Size(154, 166);
            this.picBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox1.TabIndex = 1;
            this.picBox1.TabStop = false;
            // 
            // picBox2
            // 
            this.picBox2.Location = new System.Drawing.Point(222, 43);
            this.picBox2.Name = "picBox2";
            this.picBox2.Size = new System.Drawing.Size(150, 166);
            this.picBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox2.TabIndex = 2;
            this.picBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 303);
            this.Controls.Add(this.picBox2);
            this.Controls.Add(this.picBox1);
            this.Controls.Add(this.btn_Roll);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Roll;
        private System.Windows.Forms.ImageList DiceList;
        private System.Windows.Forms.PictureBox picBox2;
        private System.Windows.Forms.PictureBox picBox1;
    }
}

