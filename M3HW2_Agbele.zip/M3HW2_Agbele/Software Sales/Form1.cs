﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Cal_Click(object sender, EventArgs e)
        {
            double Value;
            double price;
            double orignail;
            double discount;
            double total;
            price = 99;

            if (double.TryParse(txt_input.Text, out Value))
            {
                if (Value >= 1 && Value <= 9)
                {

                    orignail = price * Value;
                    discount = orignail;
                    total = orignail - discount;
                    //Total= discount 
                    dispaly_dis.Text = "0%";
                    display_price.Text = ("$" + discount);
                    display_org_price.Text = "" + orignail;
                }
                else;
                {
                    if (Value >= 10 && Value <= 19)
                    {

                        orignail = price * Value;
                        discount = orignail * .2;
                        total = orignail - discount;
                        //Total= discount 
                        dispaly_dis.Text = "20%";
                        display_price.Text = ("$" + total);
                        display_org_price.Text = "$" + orignail;
                    }
                    else;
                    {
                        if (Value >= 20 && Value <= 49)
                        {

                            orignail = price * Value;
                            discount = orignail * .3;
                            total = orignail - discount;
                            //Total= discount 
                            dispaly_dis.Text = "30%";
                            display_price.Text = ("$" + total);
                            display_org_price.Text = "$" + orignail;
                        }
                        else;
                        {
                            if (Value >= 50 && Value <= 99)
                            {

                                orignail = price * Value;
                                discount = orignail * .4;
                                total = orignail - discount;
                                //Total= discount 
                                dispaly_dis.Text = "40%";
                                display_price.Text = ("$" + total);
                                display_org_price.Text = "$" + orignail;
                            }
                            else;
                            {
                                if (Value >= 100)
                                {

                                    orignail = price * Value;
                                    discount = orignail * .5;
                                    total = orignail - discount;
                                    //Total= discount 
                                    dispaly_dis.Text = "50%";
                                    display_price.Text = ("$" + total);
                                    display_org_price.Text = "$" + orignail;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
